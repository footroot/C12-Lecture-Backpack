// Importing the required modules
const express = require("express"); // Express framework for building the server
const fs = require("fs"); // File system module to read and write to files
const cors = require("cors"); // Middleware for enabling Cross-Origin Resource Sharing (CORS)
const path = require("path"); // Module for handling and transforming file paths

// Create an instance of the express server
const app = express();

// Define the port number for the server. If the environment variable PORT is set, use that, otherwise default to 3000.
const PORT = process.env.PORT || 3000;

// Middleware to parse incoming JSON request bodies
// This enables Express to automatically parse incoming requests with JSON payloads
app.use(express.json());

// Enable Cross-Origin Resource Sharing (CORS) for the server
// This allows the server to accept requests from different domains (useful when React frontend and Express backend are on different servers)
app.use(cors());

// Define the file path for the students.json file, relative to the current directory
// Define the path to the 'students.json' file
const studFilePath = path.join(__dirname, "students.json");

// Function to read data from the 'students.json' file
const readData = () => {
  // Check if the 'students.json' file exists
  if (fs.existsSync(studFilePath)) {
    // If it exists, read the file and parse it as JSON
    const data = fs.readFileSync(studFilePath);
    return JSON.parse(data); // Return the parsed data
  }
  return []; // Return an empty array if the file doesn't exist
};

// Function to write data to the 'students.json' file
const writeData = (data) => {
  // Write the data to 'students.json' file, formatted with 2 spaces for indentation
  fs.writeFileSync(studFilePath, JSON.stringify(data, null, 2));
};

// API endpoint to get a list of all students
app.get("/api/students", (req, res) => {
  console.log("GET /api/students triggered");

  // Read the list of students from the file
  const students = readData();
  // Send the list of students as a JSON response
  res.json(students);
});

// API endpoint to get details of a single student by their ID
app.get("/api/students/:id", (req, res) => {
  // Read the list of students from the file
  const students = readData();
  // Find the student with the matching ID from the URL parameters
  const student = students.find((stud) => stud.id === req.params.id);

  // If the student is found, send their details as a JSON response
  if (student) {
    res.json(student);
  } else {
    // If the student is not found, send a 404 (Not Found) response with an error message
    res.status(404).json({ message: "Student not found" });
  }
});

// API endpoint to update a student's details by their ID
app.put("/api/students/:id", (req, res) => {
  // Read the list of students from the file
  const students = readData();
  // Find the index of the student with the matching ID
  const studentIndex = students.findIndex((s) => s.id === req.params.id);

  // If the student is found (index is not -1), update their details
  if (studentIndex !== -1) {
    // Create a new student object with the updated data (merge old data with new data from the request body)
    const updatedStudent = { ...students[studentIndex], ...req.body };
    // Replace the old student object with the updated one in the array
    students[studentIndex] = updatedStudent;

    // Write the updated students array back to the file
    writeData(students);
    // Send the updated student object as a JSON response
    res.json(updatedStudent);
  } else {
    // If the student is not found, send a 404 response with an error message
    res.status(404).json({ message: "Student not found" });
  }
});

// API endpoint to add a new student
app.post("/api/students", (req, res) => {
  console.log("POST /api/students triggered");

  // Extract name, age, and grade from the request body
  // req.body.name, req.body.age, req.body.grade
  const { name, age, grade } = req.body;

  // Read the current list of students from the file
  const students = readData();

  // Create a new student object with a unique ID based on the current timestamp
  const newStudent = { id: Date.now().toString(), name, age, grade };

  // Add the new student to the students array
  students.push(newStudent);

  // Write the updated students array back to the file
  writeData(students);

  // Respond with a status of 201 (Created) and send the new student object in the response
  res.status(201).json(newStudent);
});

// API endpoint to delete a student by their ID
app.delete("/api/students/:id", (req, res) => {
  // Read the list of students from the file
  let students = readData();
  // Store the length of the students array before deletion
  let beforeDel = students.length;
  // Filter out the student with the matching ID from the array
  students = students.filter((stud) => stud.id !== req.params.id);
  // Store the length of the students array after deletion
  let afterDel = students.length;

  // If the number of students before and after deletion is the same, it means no student was deleted
  if (beforeDel === afterDel) {
    // Send a 404 response with a message indicating the student was not found
    res.status(404).json({ message: "Student not found" });
  } else {
    // Write the updated students array back to the file
    writeData(students);
    // Send a 204 (No Content) response indicating successful deletion
    res.status(204).send();
  }
});

// API endpoint to update a student's details by their ID
app.put("/api/students/:id", (req, res) => {
  // Read the list of students from the file
  const students = readData();
  // Find the index of the student with the matching ID
  const studentIndex = students.findIndex((s) => s.id === req.params.id);

  // If the student is found (index is not -1), update their details
  if (studentIndex !== -1) {
    // Create a new student object with the updated data (merge old data with new data from the request body)
    const updatedStudent = { ...students[studentIndex], ...req.body };
    // Replace the old student object with the updated one in the array
    students[studentIndex] = updatedStudent;

    // Write the updated students array back to the file
    writeData(students);
    // Send the updated student object as a JSON response
    res.json(updatedStudent);
  } else {
    // If the student is not found, send a 404 response with an error message
    res.status(404).json({ message: "Student not found" });
  }
});

// Catch-all route for undefined endpoints
app.get("*", (req, res) => {
  // Send a response with a message indicating the resource was not found
  res.json({ message: "Resource not found" });
});

// Start the server and listen for incoming requests on the specified port
app.listen(PORT, () => {
  // Log a message indicating the server is running
  console.log(`Server is running on http://localhost:${PORT}`);
});
