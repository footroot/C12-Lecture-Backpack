import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import { Button } from "react-bootstrap";

// Component to edit an existing student's information
function EditStudent() {
  const { id } = useParams(); // Get the student ID from the URL parameter
  const navigate = useNavigate(); // Navigate to a different route programmatically
  const [student, setStudent] = useState(null);
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [grade, setGrade] = useState("");

  // Fetch the student's details when the component is mounted
  useEffect(() => {
    // Fetch the student by ID
    axios
      .get(`/api/students/${id}`)
      .then((response) => {
        setStudent(response.data); // Set the fetched student data to the state
        setName(response.data.name); // Set initial form values based on fetched student data
        setAge(response.data.age);
        setGrade(response.data.grade);
      })
      .catch((error) => console.error("Error fetching student:", error)); // Handle any errors during fetch
  }, [id]); // Re-fetch data when the student ID changes (e.g., when navigating to a different student's edit page)

  // Function to handle form submission for updating the student
  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent the default form submission behavior

    const updatedStudent = { name, age, grade };

    // Send the updated student data to the backend using a PUT request
    axios
      .put(`/api/students/${id}`, updatedStudent)
      .then(() => {
        alert("Student updated!"); // Alert the user that the student was updated successfully
        navigate("/"); // Navigate back to the student list page after successful update
      })
      .catch((error) => console.error("Error updating student:", error)); // Handle errors during the PUT request
  };

  // If student data is not yet loaded, display a loading message
  if (!student) return <p>Loading...</p>;

  return (
    <div>
      <h2>Edit Student</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Name</label>
          <input
            type="text"
            className="form-control"
            value={name}
            onChange={(e) => setName(e.target.value)} // Update name state on input change
            required={true}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Age</label>
          <input
            type="number"
            className="form-control"
            value={age}
            onChange={(e) => setAge(e.target.value)} // Update age state on input change
            required={true}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Grade</label>
          <input
            type="text"
            className="form-control"
            value={grade}
            onChange={(e) => setGrade(e.target.value)} // Update grade state on input change
            required={true}
          />
        </div>
        <Button type="submit" variant="primary">
          Update Student
        </Button>{" "}
        {/* Submit button to update student */}
      </form>
    </div>
  );
}

export default EditStudent;
