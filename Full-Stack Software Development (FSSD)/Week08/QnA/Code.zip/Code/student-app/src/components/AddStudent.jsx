import React, { useState } from "react";
import axios from "axios";
import { Button } from "react-bootstrap";

// Component to add a new student
function AddStudent() {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [grade, setGrade] = useState("");

  // Function to handle form submission for adding a new student
  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent the default form submission behavior

    const newStudent = { name, age, grade };

    // Send the new student data to the backend using a POST request
    axios
      .post("/api/students", newStudent)
      .then(() => {
        alert("Student added!"); // Alert the user that the student was added successfully

        // Clear input fields to allow make it easier to add another student
        setName("");
        setAge("");
        setGrade("");
      })
      .catch((error) => console.error("Error adding student:", error)); // Handle errors during the POST request
  };

  return (
    <div>
      <h2>Add New Student</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Name</label>
          <input
            type="text"
            className="form-control"
            value={name}
            onChange={(e) => setName(e.target.value)} // Update name state on input change
            required={true}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Age</label>
          <input
            type="number"
            className="form-control"
            value={age}
            onChange={(e) => setAge(e.target.value)} // Update age state on input change
            required={true}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Grade</label>
          <input
            type="text"
            className="form-control"
            value={grade}
            onChange={(e) => setGrade(e.target.value)} // Update grade state on input change
            required={true}
          />
        </div>
        <Button type="submit" variant="primary">
          Add Student
        </Button>{" "}
        {/* Submit button to add student */}
      </form>
    </div>
  );
}

export default AddStudent;
