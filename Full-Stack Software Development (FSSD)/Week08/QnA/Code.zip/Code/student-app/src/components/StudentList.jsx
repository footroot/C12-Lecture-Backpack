import { useState, useEffect } from "react";
import axios from "axios";
import { Button, Table } from "react-bootstrap";
import { Link } from "react-router-dom";

// Component to display list of students
function StudentList() {
  const [students, setStudents] = useState([]);

  // Fetch students when the component is mounted
  useEffect(() => {
    // Fetch student data from the Express server
    axios
      .get("/api/students")
      .then((response) => {
        setStudents(response.data); // Update the state with the students data
      })
      .catch((error) => console.error("Error fetching students:", error)); // Handle any errors during the fetch
  }, []); // Empty dependency array to fetch data only once when the component mounts

  // Function to handle the deletion of a student
  const handleDelete = (id) => {
    axios
      .delete(`/api/students/${id}`)
      .then(() => {
        // Update the student list after deletion
        setStudents(students.filter((student) => student.id !== id));
      })
      .catch((error) => console.error("Error deleting student:", error)); // Handle errors during deletion
  };

  return (
    <div>
      <h2>Students List</h2>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Name</th>
            <th>Age</th>
            <th>Grade</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {/* Render each student in the list */}
          {students.map((student) => (
            <tr key={student.id}>
              <td>{student.name}</td>
              <td>{student.age}</td>
              <td>{student.grade}</td>
              <td>
                {/* Edit button that links to the EditStudent page for the selected student */}
                <Button variant="warning" as={Link} to={`/edit/${student.id}`}>
                  Edit
                </Button>{" "}
                {/* Delete button that triggers the handleDelete function */}
                <Button
                  variant="danger"
                  onClick={() => handleDelete(student.id)}
                >
                  Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
}

export default StudentList;
