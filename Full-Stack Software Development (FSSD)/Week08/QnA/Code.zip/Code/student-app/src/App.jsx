import StudentList from "./components/StudentList";
import AddStudent from "./components/AddStudent";
import EditStudent from "./components/EditStudent";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import { Container, Nav, Navbar } from "react-bootstrap";

function App() {
  return (
    <Router>
      {/* Navbar component for navigation */}
      <Navbar bg="dark" variant="dark">
        <Container>
          <Navbar.Brand as={Link} to="/">
            Student Management
          </Navbar.Brand>
          <Nav className="ml-auto">
            <Nav.Link as={Link} to="/">
              Home
            </Nav.Link>
            <Nav.Link as={Link} to="/add">
              Add Student
            </Nav.Link>
          </Nav>
        </Container>
      </Navbar>

      {/* Main content container */}
      <Container className="mt-5" style={{ maxWidth: "600px", margin: "auto" }}>
        <Routes>
          <Route path="/" element={<StudentList />} />{" "}
          {/* Route to display student list */}
          <Route path="/add" element={<AddStudent />} />{" "}
          {/* Route to add a new student */}
          <Route path="/edit/:id" element={<EditStudent />} />{" "}
          {/* Route to edit a student */}
        </Routes>
      </Container>
    </Router>
  );
}

export default App;
